package MyPackage;

public class function_2th {

	int y=0;
	
	public int f(int a,int b,int c,int x) {
		y=a*(x*x)+b*x+c;
		return y;
	}
}
